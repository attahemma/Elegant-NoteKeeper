# Elegant-NoteKeeper
An elegant, simple to use and handy note editor
